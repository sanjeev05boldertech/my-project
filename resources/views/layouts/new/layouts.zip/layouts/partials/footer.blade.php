<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Version 1.1(Laravel-5.6)
    </div>
    <!-- Default to the left -->
    <strong>Copyright Abhi Android © 2018 <a href="https://abhiandroid.com/sourcecode/">Abhi Android</a>.</strong> All rights reserved.
</footer>